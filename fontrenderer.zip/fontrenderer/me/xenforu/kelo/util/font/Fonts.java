package me.xenforu.kelo.util.font;

import java.awt.*;

public class Fonts {
    public static final MCFontRenderer arialFont = new MCFontRenderer(new Font("Arial", Font.PLAIN,18),true,true);
    public static final MCFontRenderer latoFont = new MCFontRenderer(new Font("Lato", Font.PLAIN,18),true,true);
}
